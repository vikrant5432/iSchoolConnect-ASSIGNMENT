//pipe are function

import { Pipe, PipeTransform } from '@angular/core';

//decorate
@Pipe({
  name: 'gen',
})

// we are going to using interface pipeTransform
export class genPipe implements PipeTransform {
  //we are going to accept prameter
  //it is getting two argument
  transform(args1: any, args2: any) {
    // return 'hello pipe';
    // return 'Mr. ' + args;
    if (args2 === 'male') {
      return 'Mr. ' + args1;
    } else {
      return 'Miss. ' + args1;
    }
  }
}
