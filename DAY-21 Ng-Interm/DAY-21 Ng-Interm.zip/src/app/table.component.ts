import { Component, Input } from '@angular/core';
import { HeroDataService } from './hero.services';

@Component({
  selector: 'app-grid',
  template: `
    <p>{{ compvers }}</p>

    <table class="table table-striped table-bordered">
      <thead>
        <tr>
          <th>Sl #</th>
          <th>Title</th>
          <th>Full Name</th>
          <th>Poster</th>
          <th>City</th>
          <th>Ticket Price</th>
          <th>Release Date</th>
          <th>Movies List</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let hero of compdata">
          <td>{{ hero.sl }}</td>
          <td>{{ hero.title | uppercase }}</td>
          <td>{{ hero.firstname + ' ' + hero.lastname | gen: hero.gender }}</td>
          <td>
            <img
              class="img-thumbnail"
              [src]="hero.poster"
              [alt]="hero.title"
              width="50"
            />
          </td>
          <td>{{ hero.city }}</td>
          <td>{{ hero.ticketprice | currency: 'INR':'symbol':'3.2-4' }}</td>
          <td>{{ hero.releasedate | date: 'dd / MMMM / yyyy' }}</td>
          <td>
            <div
              class="card"
              style="width: 18rem;"
              *ngIf="hero.movieslist.length > 1"
            >
              <ul
                class="list-group list-group-flush"
                *ngFor="let movie of hero.movieslist"
              >
                <img
                  class="img-thumbnail"
                  [src]="movie.poster"
                  [alt]="movie.poster"
                  width="60"
                />
                <li class="list-group-item">{{ movie.title }}</li>
              </ul>
            </div>
          </td>
        </tr>
      </tbody>
    </table>
  `,
})
export class tableComp {
  @Input() compdata: any;
  compvers: any;
  constructor(private hds: HeroDataService) {
    this.compvers = this.hds.getHeroSerive();
  }
}
