import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  //   selector: 'ischool', //tag/element selector ===== more than 1 parameter
  //   selector: '.ischool',  //class selector  ==== no parameter
  selector: ' [ischool]', //atribute selector ===== 1 parameters
})
export class ischoolDirect implements OnInit {
  //proterties with the same name as selector
  @Input() ischool: any;

  //give a ref to element when this element that this directive is applied too
  //constructor called when the compnent its
  constructor(private elem: ElementRef) {}
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    //modify the html that is send
    this.ischool = JSON.parse(this.ischool);
    // this.elem.nativeElement.innerHTML = 'Hello from iSchool INDIA';
    this.elem.nativeElement.style.backgroundColor = this.ischool.bgcol;

    // change element
    let template = this.elem.nativeElement.innerHTML;
    this.elem.nativeElement.outerHTML =
      '<' +
      this.ischool.tagtype +
      '>' +
      template +
      '</' +
      this.ischool.tagtype +
      '>';
  }
}
