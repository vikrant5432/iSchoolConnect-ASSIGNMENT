import { Component, Input } from '@angular/core';
import { HeroDataService } from './hero.services';

@Component({
  selector: 'app-header',
  template: `
    <p>{{ compvers }}</p>

    <ul class="nav justify-content-center">
      <li class="nav-item" *ngFor="let hero of compdata">
        <a class="nav-link" href="#">{{ hero.title }}</a>
      </li>
    </ul>
  `,
})
export class headerComp {
  @Input() compdata: any;
  compvers: any;
  constructor(private hds: HeroDataService) {
    this.compvers = this.hds.getHeroSerive();
  }
}
