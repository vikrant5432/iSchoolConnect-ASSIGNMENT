import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { headerComp } from './header.component';
import { HeroDataService } from './hero.services';
import { tableComp } from './table.component';
import { genPipe } from './gen.pipe';
import { ischoolDirect } from './ischool.directive';

@NgModule({
  declarations: [AppComponent, headerComp, tableComp, genPipe, ischoolDirect],
  // import module rsjs
  imports: [BrowserModule, HttpClientModule],
  providers: [HeroDataService],
  bootstrap: [AppComponent],
})
export class AppModule {}
