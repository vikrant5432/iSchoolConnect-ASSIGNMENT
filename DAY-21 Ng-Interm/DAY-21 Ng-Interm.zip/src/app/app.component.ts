import { Component } from '@angular/core';
import { HeroDataService } from './hero.services';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>Angular Data Handling</h1>
      <p>{{ compvers }}</p>
      <hr />
      <app-header [compdata]="herodata"></app-header>
      <hr />
      <app-grid [compdata]="herodata"></app-grid>
      <hr />
      <!-- ng-template -->
      <!-- <ischool>
        <p>Some Content</p>
      </ischool>
      <ischool>
        <p>Some Content</p>
      </ischool>
      <ischool>
        <p>Some Content</p>
      </ischool> -->

      <!-- <p class="ischool">Some Content</p>
      <p class="ischool">Some Content</p>
      <p class="ischool">Some Content</p> -->

      <!-- <p ischool=" red">Some Content</p>
      <p ischool=" Yellow">Some Content</p>
      <p ischool=" green">Some Content</p> -->
      <p ischool='{"txtcol": "green", "bgcol":"orange", "tagtype": "button"}'>
        Some Content
      </p>
    </div>
  `,
})
export class AppComponent {
  title = 'STEPS';
  herodata: any;
  compvers: any;
  // hds:HeroDataService=new HeroDataService();
  // constructor(){
  //   this.herodata=this.hds.getHeroData();
  // }

  // constructor(private hds: HeroDataService) {
  //   this.compvers = this.hds.getHeroSerive();
  //   this.herodata = this.hds.getHeroData();
  // }
  constructor(private hds: HeroDataService) {
    this.compvers = this.hds.getHeroSerive();
    this.hds.getHeroData().subscribe((res) => (this.herodata = res));
  }
}
