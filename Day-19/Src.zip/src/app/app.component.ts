import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div>
      <h2>Hero Application</h2>
      <img #hero src="images/rajani.jpg" alt="damn" />
      <br />
      <!-- attribute binding -->
      <button [disabled]="agree">click me</button>
      <!-- for event handler -->
      <!-- <button (click)="clickHandler()">click me</button> -->
      <!-- event handler -->
      <button on-click="clickHandler($event)">button 1</button>
      <button on-click="clickHandler($event)">button 2</button>
      <button on-click="clickHandler($event)">button 3</button>
      <button (click)="setAgreeDisagree()">button :- Agree/Disagree</button>

      <hr />
      <button (click)="hero.src = 'images/rajani.jpg'">Rajani</button>
      <button (click)="hero.src = 'images/batman.jpg'">Batman</button>
      <button (click)="hero.src = 'images/antman.jpg'">Antman</button>
      <button (click)="hero.src = 'images/hulk.jpg'">Hulk</button>

      <hr />
      <h3>{{ title }}</h3>
      <input #change [value]="title" (input)="changeTitle(change.value)" />
      <button (click)="changeTitle(change.value)">Change title</button>
      <hr />
      <input [value]="title" #change1 (input)="title = change1.value" />

      <br />
      <h3>2 way Binding</h3>
      <input [(ngModel)]="title" />

      <h3>{{ user?.title || 'title is yet to come' }}</h3>

      <input type="text" (keydown.ArrowLeft)="keyPressHandler()" />

      <!-- box is the class for this div -->
      <div class="orangeBox" [class.box]="agree">
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Quis
        modiperferendis dolore veritatis ullam eveniet, illo animi mollitia
        dignissimos sint recusandae amet tenetur unde autem illum blanditiis eum
        ex accusamus?
      </div>
    </div>
  `,
  styles: [
    `
      .box {
        width: 500px;
        padding: 10px;
      }
      .orangeBox {
        background-color: orange;
      }
    `,
  ],
})
export class AppComponent {
  title = 'STEP-1';
  agree = true;
  user = { title: '' };
  clickHandler(event?: any) {
    if (event) {
      alert('Hello there:-' + event.target.innerHTML);
    } else {
      alert('you click a button');
    }
  }
  setAgreeDisagree() {
    this.agree = !this.agree;
  }

  changeTitle(ntitle: string) {
    this.title = ntitle;
    // this.user.title = 'Ironman';
  }

  keyPressHandler() {
    console.log('key was pressed');
  }
}
