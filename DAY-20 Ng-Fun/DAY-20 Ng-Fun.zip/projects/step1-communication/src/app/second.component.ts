import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-second',
  template: `
    <h1>second works!</h1>
    <!-- <ng-content></ng-content> -->
    <!-- we can use selector to render any element we want -->
    <!-- filter is done for root element -->
    <!-- <ng-content select="button"></ng-content> -->
    <!-- <ng-content select="p.para1"></ng-content> -->
    <!-- <ng-content select="ul"></ng-content> -->
    <!-- it will not work not child element -->
    <!-- <ng-content select="ul>li.test"></ng-content> -->

    <h2>power is {{ comPower }}</h2>
    <input type="text" #ti />
    <button (click)="emitCompEvent(ti.value)">send message</button>
  `,
})
export class SecondComponent {
  // by default compower is public
  //now the comPower will be used in other component
  //we can use alias of the name
  @Input('cp') comPower: number = 34;
  @Output() comEvent: EventEmitter<any> = new EventEmitter();
  emitCompEvent(msg: string) {
    this.comEvent.emit(msg);
  }
}
