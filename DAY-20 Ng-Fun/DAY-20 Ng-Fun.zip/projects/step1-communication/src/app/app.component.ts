import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <!--The content below is only a placeholder and can be replaced.-->
    <!-- <h1>{{ title }}</h1>
    <hr />
    parameter for the second angular component 
    <app-second>{{ message }}</app-second>
    <app-second>
      <ul>
        <li class="test">list no: 1</li>
        <li>list no: 2</li>
        <li>list no: 3</li>
        <li>list no: 4</li>
      </ul>
      <p class="para1">
        first paragraph <br />
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam tenetur
        beatae corporis aspernatur assumenda dignissimos voluptas, sed ipsam sit
        quam, provident, veniam pariatur mollitia. Repellat quia at ad
        voluptatem consectetur?
      </p>
      <p>
        second paragraph <br />
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Ullam libero
        ipsam quia iste odit assumenda est, consequuntur, eaque accusantium
        sequi quam autem facere reprehenderit ab nihil beatae veniam sint ea!
      </p>
      <button>click me</button>
    </app-second> -->

    <app-second [cp]="power" (comEvent)="eventHandler($event)"></app-second>
    <button (click)="power = power + 1">increse number</button>
  `,
  styles: [],
})
export class AppComponent {
  title = 'step1-communication';
  message = 'Hello iSchool';
  power = 45;
  eventHandler(msg: string) {
    alert(msg);
  }
}
