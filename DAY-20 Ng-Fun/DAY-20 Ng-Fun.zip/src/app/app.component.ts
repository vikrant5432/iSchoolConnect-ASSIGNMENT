import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <!-- <div
      class="box"
      [class.bluebox]="showcolor"
      [class.roundborder]="showBorder"
    >
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Deserunt ut
      sequi recusandae ratione. Voluptatem nisi facere vitae natus, earum quo
      tenetur molestiae eum necessitatibus velit recusandae blanditiis rem
      nesciunt. Soluta?
    </div> -->

    <div
      [ngStyle]="{
        'background-color': showColor ? 'pink' : 'blue',
        padding: '10px',
        border: '10px solid red'
      }"
    >
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Dolores culpa
      labore unde aut consectetur itaque nesciunt quos saepe possimus a
      molestiae nostrum eaque tempora iste amet pariatur iusto, architecto
      reprehenderit?
    </div>

    <hr />
    <p>Show Term and Conditions</p>
    <input type="checkbox" (input)="showCondition = !showCondition" />
    <fieldset *ngIf="showCondition">
      <legend>Term and Condition</legend>
      <p>
        Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quisquam
        ipsum, itaque officiis deserunt sint doloremque error voluptates,
        facilis voluptas molestias, porro consectetur voluptate tempore.
        Veritatis doloremque ipsum voluptates autem ipsam.
      </p>
    </fieldset>

    <hr />
    <!-- loop through an array using *ngFor -->
    <ol>
      <li *ngFor="let hero of heros">{{ hero }}</li>
    </ol>
    <hr />
    <h3 ngNonBindable>Hello {{ vikrant }}</h3>
    <!-- templete reference -->
    <input type="range" #pow (input)="power = pow.value" min="5" max="10" />
    <h2>Power is : {{ power }}</h2>
    <ul [ngSwitch]="power">
      <li *ngSwitchCase="6">Weak : {{ power }}</li>
      <li *ngSwitchCase="7">Booster Required : {{ power }}</li>
      <li *ngSwitchCase="8">Strong : {{ power }}</li>
      <li *ngSwitchCase="9">Strongest : {{ power }}</li>
      <li *ngSwitchCase="10">Invinsible : {{ power }}</li>
      <li *ngSwitchDefault>Defaut Power : {{ power }}</li>
    </ul>
    <hr />
    <!-- redundant element -->
    <!-- if we don't want to use element to print  -->
    <ng-template [ngIf]="showCondition">{{ title }}</ng-template>
    <ng-template [ngIf]="showCon">
      <app-second></app-second>
    </ng-template>
  `,
  styles: [
    `
      .box {
        width: 400px;
        height: 150px;
        padding: 10px;
        outline: 1px solid black;
      }
      .bluebox {
        background-color: lightblue;
      }
      .roundborder {
        border: 10px solid gray;
        border-radius: 40px;
      }
    `,
  ],
})
export class AppComponent {
  title = 'Hello World';
  showColor = false;
  showBorder = true;
  showCondition = false;
  showCon = true;
  power = '5';
  heros = ['naruto', 'Luffy', 'Sasuki', 'Remuro', 'Tempesto'];
}
