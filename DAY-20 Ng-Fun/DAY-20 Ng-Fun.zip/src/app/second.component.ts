import { Component } from '@angular/core';

@Component({
  selector: 'app-second',
  template: ` <p>Hello World</p> `,
})
export class secondComp {}
