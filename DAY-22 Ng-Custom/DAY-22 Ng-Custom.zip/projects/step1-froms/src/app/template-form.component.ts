import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';

//name
//age
//mail
@Component({
  selector: 'app-template-form',
  template: `
    <h2>Template driven form</h2>

    <!-- validate -->
    <form
      #myForm="ngForm"
      action="#"
      name="nyname"
      (submit)="formSubmitHandler(myForm, $event)"
      method="get"
      novalidate
    >
      <!-- referance and name -->
      <div class="mb-3">
        <label for="username" class="form-label">User Name:-</label>
        <!-- template referance help the angular to understand that we are taking input -->
        <input
          #uname="ngModel"
          name="uname"
          type="text"
          [(ngModel)]="user.name"
          id="username"
          required
          class="form-control"
        />
        <span class="form-text" *ngIf="uname.invalid && uname.touched"
          >Please enter your name</span
        >
      </div>
      <div class="mb-3">
        <label for="userage" class="form-label">User Age:-</label>
        <input
          #uage="ngModel"
          name="uage"
          type="number"
          min="18"
          max="70"
          [(ngModel)]="user.age"
          id="userage"
          required
          class="form-control"
        />
        <span class="form-text" *ngIf="uage.invalid && uage.touched"
          >Please enter your age. It must be between 18 to 70</span
        >
      </div>
      <div class="mb-3">
        <label for="usermail" class="form-label">User Email:-</label>
        <input
          #umail="ngModel"
          name="umail"
          pattern=".+@.+"
          type="text"
          [(ngModel)]="user.mail"
          id="usermail"
          required
          class="form-control"
        />
        <span class="form-text" *ngIf="umail.invalid && umail.touched"
          >Please enter a valid mail id</span
        >
      </div>
      <button type="submit" class="btn btn-primary">Register</button>
    </form>
    <!-- 2 way data binding -->
    <ul>
      <li>User name:-{{ user.name }}</li>
      <li>User age: {{ user.age }}</li>
      <li>User Email: {{ user.mail }}</li>
    </ul>
    <ul>
      <li *ngIf="uname.touched">User Name:-Touched</li>
      <li *ngIf="uname.untouched">User Name:-Untouched</li>
      <li *ngIf="uname.pristine">User Name:-pristine</li>
      <li *ngIf="uname.dirty">User Name:-dirty</li>
      <li *ngIf="uname.valid">User Name:-valid</li>
      <li *ngIf="uname.invalid">User Name:-invalid</li>
    </ul>
    <ul>
      <li *ngIf="uage.touched">User Age:-Touched</li>
      <li *ngIf="uage.untouched">User Age:-Untouched</li>
      <li *ngIf="uage.pristine">User Age:-pristine</li>
      <li *ngIf="uage.dirty">User Age:-dirty</li>
      <li *ngIf="uage.valid">User Age:-valid</li>
      <li *ngIf="uage.invalid">User Age:-invalid</li>
    </ul>
    <ul>
      <li *ngIf="umail.touched">User Mail:-Touched</li>
      <li *ngIf="umail.untouched">User Mail:-Untouched</li>
      <li *ngIf="umail.pristine">User Mail:-pristine</li>
      <li *ngIf="umail.dirty">User Mail:-dirty</li>
      <li *ngIf="umail.valid">User Mail:-valid</li>
      <li *ngIf="umail.invalid">User Mail:-invalid</li>
    </ul>
  `,
  styles: [
    `
      /* predefine class for css */
      input.ng-valid {
        border: 2px solid greenyellow;
      }
      input.ng-invalid.ng-touched {
        border: 2px solid crimson;
      }
    `,
  ],
})
export class templateForm {
  user = {
    name: '',
    age: '',
    mail: '',
  };
  formSubmitHandler(userform: NgForm, event: any) {
    event.preventDefault();
    console.log(userform);
    let info = userform.form.value;
    if (info.uname && info.uage && info.umail) {
      if (info.uage < 18) {
        alert('you are too young to join this');
      } else if (info.uage > 70) {
        alert('you are too old to join this');
      } else {
        event.target.submit();
      }
    } else {
      alert('you must Complete the form fill up');
    }
  }
}
