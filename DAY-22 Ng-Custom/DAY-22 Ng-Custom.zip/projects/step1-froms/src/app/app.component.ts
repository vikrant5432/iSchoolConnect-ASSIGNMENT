import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h2>Form in Angular</h2>
    <hr />
    <app-template-form></app-template-form>
  `,
  styles: [],
})
export class AppComponent {
  title = 'step1-froms';
}
