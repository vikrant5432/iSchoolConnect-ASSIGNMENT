import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'keyVal',
})
export class ischoolPipe implements PipeTransform {
  transform(arg1: any) {
    return arg1.title + ' is from ' + arg1.region;
  }
}
