import { Directive, ElementRef, Input, OnInit } from '@angular/core';

@Directive({
  selector: '[ischool]',
})
export class styleDirect implements OnInit {
  @Input() ischool: any;
  constructor(private elem: ElementRef) {}
  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    // this.ischool = JSON.parse(this.ischool);
    console.log(this.ischool.color);
    this.elem.nativeElement.style.backgroundColor = this.ischool.color;
    this.elem.nativeElement.style.padding = '10px';
  }
}
