import { NgModule } from '@angular/core';
import { ischoolComp } from './ischool.component';
import { ischoolPipe } from './ischoolregion.pipe';
import { styleDirect } from './ischoolstyle.directive';

@NgModule({
  declarations: [ischoolComp, ischoolComp, styleDirect, ischoolPipe],
  imports: [],
  exports: [ischoolComp, ischoolComp, styleDirect, ischoolPipe],
})
export class iSchoolModule {
    
}
