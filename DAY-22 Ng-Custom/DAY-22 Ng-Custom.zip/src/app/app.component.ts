import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div>
      <h1>Participant List</h1>
      <hr />
      <div *ngFor="let part of participants">
        <app-ischool [part]="part"></app-ischool>
      </div>
    </div>
  `,
})
export class AppComponent {
  title = 'STEPS-1';
  //array of objects
  participants = [
    { title: 'Rajesh Kumar', region: 'north', color: '#FF9933' },
    { title: 'Abdullah Taqi', region: 'north', color: '#49FCBB' },
    { title: 'Harshal Patil', region: 'west', color: '#D6E637' },
    { title: 'Harshita Verma', region: 'central', color: '#FE3DA4' },
    { title: 'Harvendra Singh Rathore', region: 'central', color: '#3742E6' },
    { title: 'Ishika joshi', region: 'central', color: '#sF86EB' },
    { title: 'Khai Sing Wu', region: 'east', color: '#6295E0' },
    { title: 'Mani Varshney', region: 'east', color: '#00FF00 ' },
    { title: 'Renu Verma', region: 'north', color: '#0AA5F0' },
    { title: 'Sainath Arjun', region: 'south', color: '#00FF0F ' },
    { title: 'Suriya Prakash', region: 'south', color: '#5CE618' },
    { title: 'Vikrant Kumar', region: 'east', color: '#FF9221' },
  ];
}
