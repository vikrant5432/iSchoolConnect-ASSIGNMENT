import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-ischool',
  template: ` <h4 [ischool]="part">{{ part | keyVal }}</h4> `,
})
export class ischoolComp {
  @Input() part = {
    title: '',
    region: '',
    color: '',
  };
}
