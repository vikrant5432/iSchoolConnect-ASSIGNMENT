import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ischoolComp } from './ischool.component';
import { iSchoolModule } from './ischool.module';
import { ischoolPipe } from './ischoolregion.pipe';
import { styleDirect } from './ischoolstyle.directive';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, iSchoolModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
