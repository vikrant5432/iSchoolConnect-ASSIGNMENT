"use strict";
// let hero: Array<string> = ["vikrant", "time", "name"];
// let hero: string[] = ["Vikrant", "time", "name"];
/*
class Hero {
  title: string;
  constructor(ntitle: string) {
    this.title = ntitle;
  }
  sayTitle(){
      console.log(this.title)
  }
}
*/
/*
class Hero {
  public title: string;
  constructor(ntitle: string) {
    this.title = ntitle;
  }
  sayTitle() {
    console.log(this.title);
  }
}
*/
class Hero {
    constructor(title, fname, lname) {
        this.title = title;
        this.fname = fname;
        this.lname = lname;
    }
    sayTitle() {
        console.log(this.title);
    }
    sayfull() {
        console.log(this.fname + " " + this.lname);
    }
}
let hero = new Hero("hero", "Virkant", "kumar");
hero.sayTitle();
hero.sayfull();
///function advantages in typescript
let message = "";
function saymessage(part1, part2) {
    return part1 + " " + part2;
}
function logmessage(part1, part2, part3) {
    console.log(part1 + " " + part2);
}
document.addEventListener("DOMContentLoaded", () => {
    var _a;
    (_a = document.querySelector(".log")) === null || _a === void 0 ? void 0 : _a.innerHTML = saymessage("Vikrant", "Kumar");
    logmessage("hello", "world");
});
