"use strict";
// /*
// let message: string = "welcome to iSchool";
// let count: number = 34;
// let show: boolean = false;
// let hero: Array<string> = [""];
// let obj: object = {};
// */
// //union type
// /*
// let message: string | number = "hi there";
// message = "hello";
// message = 345;
// */
// //any type is allow
// let message: any = "Helo friend";
// message = false;
// message = ["hi", "ther"];
// alert(message);
