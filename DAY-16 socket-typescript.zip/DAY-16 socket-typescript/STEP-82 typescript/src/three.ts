// let hero: Array<string> = ["vikrant", "time", "name"];
// let hero: string[] = ["Vikrant", "time", "name"];

/*
class Hero {
  title: string;
  constructor(ntitle: string) {
    this.title = ntitle;
  }
  sayTitle(){
      console.log(this.title)
  }
}
*/
/*
class Hero {
  public title: string;
  constructor(ntitle: string) {
    this.title = ntitle;
  }
  sayTitle() {
    console.log(this.title);
  }
}
*/
class Hero {
  constructor(
    public title: string,
    public fname: string,
    public lname: string
  ) {}
  sayTitle() {
    console.log(this.title);
  }
  sayfull() {
    console.log(this.fname + " " + this.lname);
  }
}

let hero = new Hero("hero", "Virkant", "kumar");
hero.sayTitle();
hero.sayfull();

///function advantages in typescript
let message: string = "";
function saymessage(part1: string, part2: string) {
  return part1 + " " + part2;
}

function logmessage(part1: string, part2: string, part3: string): void {
  console.log(part1 + " " + part2);
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelector(".log")?.innerHTML = saymessage("Vikrant", "Kumar");
  logmessage("hello", "world");
});
