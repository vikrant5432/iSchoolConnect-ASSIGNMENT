// const express = require("express");
// const app = express();
// //to handle low API
// const http = require("http").createServer(app);
// // server is configured to do client side listening
// const io = require("socket.io")(http);

// app.use(express.static(__dirname));
// app.use(express.static(__dirname + "/public"));

// let connectlist = 1;
// //;
// //refresh is like new connection

// //socket are disconnect not the server (remember important)
// io.on("connection", (socket) => {
//   console.log("socket connection sucession");
//   socket.emit("serverMessage", "client connected" + connectlist);
//   connectlist++;
//   socket.on("disconnect", () => {
//     console.log("client is disconnected");
//   });
// });

// http.listen(2020);
// console.log("Server is live on localhost:2020");
