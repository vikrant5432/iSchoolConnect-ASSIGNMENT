const express = require("express");
const app = express();
//to handle low API
const http = require("http").createServer(app);
// server is configured to do client side listening
const io = require("socket.io")(http);

app.use(express.static(__dirname));
app.use(express.static(__dirname + "/public"));

io.on("connection", (socket) => {
  console.log("socket connection sucession");
  socket.emit("serverMessage", "client connected");

  socket.on("clientMessage", (res) => {
    io.emit("serverMessage", {
      username: res.username,
      message: res.message,
    });
  });

  socket.on("disconnect", () => {
    console.log("client is disconnected");
  });
});

http.listen(2020);
console.log("Server is live on localhost:2020");
