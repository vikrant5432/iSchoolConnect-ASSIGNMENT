let AddPower = (config: any) => {
  return (targetClass: any) => {
    return class {
      title = new targetClass().title;
      power = config.power;
      city = config.city;
    };
  };
};

@AddPower({
  power: 45,
  city: "jaipur",
})
//add power will add to commanMan and then commanMan will become target class to assgin value to title,power,city
class CommanMan {
  title = "spidermen";
}

let batman = new CommanMan();
console.log(batman);
