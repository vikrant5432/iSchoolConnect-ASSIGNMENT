const express = require("express");
const app = express();

app.get("/", (req, res) => {
  //response have to end() after any response activity
  /*
  res.write("hello there");
  res.end();
  */
  //   res.send("<h1>hello doabalo</h1>");
  res.sendFile(__dirname + "/index.html");
});

app.listen(2020, "localhost");
console.log("sever is alive");
